// API Base URL
const API_URL = 'http://localhost:8080/api/tasks';

// Initialize app when page loads
document.addEventListener('DOMContentLoaded', function() {
    loadAllTasks();
    setupEventListeners();
});

// Setup event listeners
function setupEventListeners() {
    // Add task form submit
    document.getElementById('addTaskForm').addEventListener('submit', handleAddTask);
    
    // Edit task form submit
    document.getElementById('editTaskForm').addEventListener('submit', handleEditTask);
    
    // Modal close button
    document.querySelector('.close').addEventListener('click', closeEditModal);
    
    // Close modal when clicking outside
    window.addEventListener('click', function(event) {
        const modal = document.getElementById('editModal');
        if (event.target === modal) {
            closeEditModal();
        }
    });
}

// Load all tasks from API
async function loadAllTasks() {
    try {
        const response = await fetch(API_URL);
        const tasks = await response.json();
        
        // Clear all lists
        clearAllLists();
        
        // Group tasks by status
        tasks.forEach(task => {
            addTaskToList(task);
        });
        
        // Update counts
        updateAllCounts();
    } catch (error) {
        console.error('Error loading tasks:', error);
        alert('Taskları yükləyərkən xəta baş verdi. Backend serverin işlədiyindən əmin olun.');
    }
}

// Clear all task lists
function clearAllLists() {
    document.getElementById('todoList').innerHTML = '';
    document.getElementById('progressList').innerHTML = '';
    document.getElementById('pausedList').innerHTML = '';
    document.getElementById('doneList').innerHTML = '';
    document.getElementById('finishedList').innerHTML = '';
}

// Add task to appropriate list
function addTaskToList(task) {
    const taskCard = createTaskCard(task);
    const listId = getListIdFromStatus(task.status);
    const list = document.getElementById(listId);
    
    if (list) {
        list.appendChild(taskCard);
    }
}

// Get list ID based on status
function getListIdFromStatus(status) {
    const statusMap = {
        'TODO': 'todoList',
        'IN_PROGRESS': 'progressList',
        'PAUSED': 'pausedList',
        'DONE': 'doneList',
        'FINISHED': 'finishedList'
    };
    return statusMap[status] || 'todoList';
}

// Create task card element
function createTaskCard(task) {
    const card = document.createElement('div');
    card.className = 'task-card';
    card.draggable = true;
    card.dataset.taskId = task.id;
    
    // Format date
    const date = new Date(task.createdAt);
    const formattedDate = date.toLocaleDateString('az-AZ', { 
        year: 'numeric', 
        month: 'short', 
        day: 'numeric',
        hour: '2-digit',
        minute: '2-digit'
    });
    
    card.innerHTML = `
        <div class="task-card-header">
            <span class="task-title">${escapeHtml(task.title)}</span>
            <div class="task-actions">
                <button class="task-btn edit-btn" onclick="openEditModal(${task.id})" title="Redaktə et">✏️</button>
                <button class="task-btn delete-btn" onclick="deleteTask(${task.id})" title="Sil">🗑️</button>
            </div>
        </div>
        ${task.description ? `<div class="task-description">${escapeHtml(task.description)}</div>` : ''}
        <span class="task-date">📅 ${formattedDate}</span>
    `;
    
    // Add drag event listeners
    card.addEventListener('dragstart', handleDragStart);
    card.addEventListener('dragend', handleDragEnd);
    
    return card;
}

// Escape HTML to prevent XSS
function escapeHtml(text) {
    const div = document.createElement('div');
    div.textContent = text;
    return div.innerHTML;
}

// Handle add task form submission
async function handleAddTask(e) {
    e.preventDefault();
    
    const title = document.getElementById('taskTitle').value.trim();
    const description = document.getElementById('taskDescription').value.trim();
    
    if (!title) {
        alert('Zəhmət olmasa task başlığını daxil edin!');
        return;
    }
    
    const taskData = {
        title: title,
        description: description,
        status: 'TODO'
    };
    
    try {
        const response = await fetch(API_URL, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify(taskData)
        });
        
        if (response.ok) {
            // Clear form
            document.getElementById('addTaskForm').reset();
            
            // Reload tasks
            await loadAllTasks();
            
            alert('✅ Task uğurla əlavə edildi!');
        } else {
            throw new Error('Failed to create task');
        }
    } catch (error) {
        console.error('Error creating task:', error);
        alert('Task əlavə edərkən xəta baş verdi!');
    }
}

// Open edit modal
async function openEditModal(taskId) {
    try {
        const response = await fetch(`${API_URL}/${taskId}`);
        const task = await response.json();
        
        document.getElementById('editTaskId').value = task.id;
        document.getElementById('editTaskTitle').value = task.title;
        document.getElementById('editTaskDescription').value = task.description || '';
        document.getElementById('editTaskStatus').value = task.status;
        
        document.getElementById('editModal').style.display = 'block';
    } catch (error) {
        console.error('Error loading task:', error);
        alert('Task məlumatlarını yükləyərkən xəta baş verdi!');
    }
}

// Close edit modal
function closeEditModal() {
    document.getElementById('editModal').style.display = 'none';
    document.getElementById('editTaskForm').reset();
}

// Handle edit task form submission
async function handleEditTask(e) {
    e.preventDefault();
    
    const taskId = document.getElementById('editTaskId').value;
    const title = document.getElementById('editTaskTitle').value.trim();
    const description = document.getElementById('editTaskDescription').value.trim();
    const status = document.getElementById('editTaskStatus').value;
    
    if (!title) {
        alert('Zəhmət olmasa task başlığını daxil edin!');
        return;
    }
    
    const taskData = {
        title: title,
        description: description,
        status: status
    };
    
    try {
        const response = await fetch(`${API_URL}/${taskId}`, {
            method: 'PUT',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify(taskData)
        });
        
        if (response.ok) {
            closeEditModal();
            await loadAllTasks();
            alert('✅ Task uğurla yeniləndi!');
        } else {
            throw new Error('Failed to update task');
        }
    } catch (error) {
        console.error('Error updating task:', error);
        alert('Task yeniləyərkən xəta baş verdi!');
    }
}

// Delete task
async function deleteTask(taskId) {
    if (!confirm('Bu task-ı silmək istədiyinizdən əminsiniz?')) {
        return;
    }
    
    try {
        const response = await fetch(`${API_URL}/${taskId}`, {
            method: 'DELETE'
        });
        
        if (response.ok) {
            await loadAllTasks();
            alert('✅ Task uğurla silindi!');
        } else {
            throw new Error('Failed to delete task');
        }
    } catch (error) {
        console.error('Error deleting task:', error);
        alert('Task silərkən xəta baş verdi!');
    }
}

// Update all task counts
function updateAllCounts() {
    const counts = {
        'todoCount': document.getElementById('todoList').children.length,
        'progressCount': document.getElementById('progressList').children.length,
        'pausedCount': document.getElementById('pausedList').children.length,
        'doneCount': document.getElementById('doneList').children.length,
        'finishedCount': document.getElementById('finishedList').children.length
    };
    
    Object.keys(counts).forEach(countId => {
        document.getElementById(countId).textContent = counts[countId];
    });
}

// Drag and Drop Functions
let draggedElement = null;

function handleDragStart(e) {
    draggedElement = this;
    this.classList.add('dragging');
    e.dataTransfer.effectAllowed = 'move';
    e.dataTransfer.setData('text/html', this.innerHTML);
}

function handleDragEnd(e) {
    this.classList.remove('dragging');
    
    // Remove drag-over class from all lists
    document.querySelectorAll('.task-list').forEach(list => {
        list.classList.remove('drag-over');
    });
}

function allowDrop(e) {
    e.preventDefault();
    e.dataTransfer.dropEffect = 'move';
    
    // Add visual feedback
    const taskList = e.currentTarget;
    if (taskList.classList.contains('task-list')) {
        taskList.classList.add('drag-over');
    }
}

async function drop(e) {
    e.preventDefault();
    
    const taskList = e.currentTarget;
    taskList.classList.remove('drag-over');
    
    if (draggedElement) {
        const taskId = draggedElement.dataset.taskId;
        const newStatus = taskList.parentElement.dataset.status;
        
        // Update task status in backend
        try {
            const response = await fetch(`${API_URL}/${taskId}/status`, {
                method: 'PATCH',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify({ status: newStatus })
            });
            
            if (response.ok) {
                // Reload tasks to reflect changes
                await loadAllTasks();
            } else {
                throw new Error('Failed to update task status');
            }
        } catch (error) {
            console.error('Error updating task status:', error);
            alert('Task statusunu dəyişərkən xəta baş verdi!');
            // Reload to revert changes
            await loadAllTasks();
        }
    }
}