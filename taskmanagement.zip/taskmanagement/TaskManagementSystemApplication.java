package com.taskmanagement;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TaskManagementSystemApplication {

    public static void main(String[] args) {
        SpringApplication.run(TaskManagementSystemApplication.class, args);
        System.out.println("\n===========================================");
        System.out.println("Task Management System Started Successfully!");
        System.out.println("API is running on: http://localhost:8080");
        System.out.println("===========================================\n");
    }
}