package com.taskmanagement.repository;

import com.taskmanagement.model.Task;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import java.util.List;

@Repository
public interface TaskRepository extends JpaRepository<Task, Long> {

    // Find all tasks by status
    List<Task> findByStatus(String status);

    // Find tasks by title containing keyword
    List<Task> findByTitleContainingIgnoreCase(String keyword);

    // Find all tasks ordered by creation date
    List<Task> findAllByOrderByCreatedAtDesc();
}